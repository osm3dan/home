---
layout: post
title:  "This website open!"
title_jp: "ホームページを開設"
date:   2020-10-15 18:00:00 0900
blurb: "Webpage started"
og_image:
tag: news
category: en
cont: HP update
year: 2020
---

#### **Hellow, world!**

I opened this personal website! Information of my reserch activities will be updated here! Please check it out!
