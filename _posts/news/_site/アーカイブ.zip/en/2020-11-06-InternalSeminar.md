---
layout: post
title:  "Internal Seminar @NIED"
title_jp:  "所内セミナー@防災科研"
date:   2020-11-06 13:30:00 0900
blurb: "Presentation at NIED / セミナー発表 at 防災科研"
og_image:
tag: news
category: en
cont: Conference
year: 2020
---

#### **Confference**

I presented at **Volcanology Seminar (Internal Seminar at NIED)**.

- [Date Time] 2020年10月31日(土) 14:00 〜 14:15
- [Seminar] Volcanology Seminar (internal at NIED)
- [Title] **Volcanic earthquakes generating unusual tsunamis: Observational evidence of trapdoor faulting at submarine calderas**
- [発表者] Osamu Sandanbata
