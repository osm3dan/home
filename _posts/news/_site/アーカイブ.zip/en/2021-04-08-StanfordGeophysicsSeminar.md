---
layout: post
title:  "Stanford Geophysics Seminar (Invited)"
title_jp:  "[セミナー発表] Marine Seismology Symposium"
date:   2021-04-09 4:00:00 +0900
blurb: "Stanford Geophysics Seminarで発表 / Talk in Stanford Geophysics Seminar"
og_image:
tag: news
category: en
cont: Seminar
year: 2021
---

#### **Seminar**

I talked at [**Stanford Geophysics Seminar**](https://earth.stanford.edu/events/osamu-sandanbata-university-tokyo-abnormal-tsunamis-caused-trapdoor-faulting).

- [Place] Online
- [Date Time] 12:00 PM - 13:00 PM  on Friday, April 8, 2021 (PDT/UTC-07)
- [Title] **Abnormal tsunamis caused by trapdoor faulting repeating at submarine volcanic calderas**
- [Authors] Osamu Sandanbata

You can watch the video of the seminar talk in [here](https://drive.google.com/file/d/1eFPH4R5KV6ciSwtswRrCj8wj4fE07Cia/view)!
