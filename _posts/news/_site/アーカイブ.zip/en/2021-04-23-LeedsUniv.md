---
layout: post
title:  "University of Leeds, Volcanology Seminar (Invited)"
title_jp:  "[セミナー発表] University of Leeds, Volcanology Seminar (招待講演)"
date:   2021-04-23 19:00:00 +0900
blurb: "University of Leeds, Volcanology Seminarで発表 / Talk at University of Leeds, Volcanology Seminar"
og_image:
tag: news
category: en
cont: Seminar
year: 2021
---

#### **Seminar**

I talked at [**University of Leeds, Volcanology Seminar**](https://environment.leeds.ac.uk/institute-geophysics-tectonics/doc/volcanology).

- [Place] Online
- [Date Time] 10:00 AM - 11:00 AM  on Friday, April 23, 2021 (UTC)
- [Title] **Investigations of ring-faulting at active calderas: Case studies at Sierra Negra caldera in Galápagos, and Smith caldera in Japan**
- [Authors] Osamu Sandanbata
