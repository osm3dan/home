---
layout: post
title:  "Publication from GJI (1st author)""
title_jp: "出版: JGR-Solid Earth"
date:   2021-05-17 00:00:00 0900
blurb: "Paper published from GJI"
og_image:
tag: news
category: en
cont: Paper
year: 2021
---

#### **Paper published from Geophysical Journal International**

My first-authored paper has been published from *Geophysical Journal International*!
The co-authors are Drs. Shingo Watada, Tung-Cheng Ho, and Kenji Satake.
You can check the detailed information in "[Works](https://osm3dan.github.io/en/publications)".

The paper is available in [*Geophysical Journal International*](https://doi.org/10.1093/gji/ggab192).
