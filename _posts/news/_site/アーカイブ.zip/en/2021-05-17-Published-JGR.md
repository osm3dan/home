---
layout: post
title:  "Publication from JGR-Solid Earth (1st author)""
title_jp: "出版: JGR-Solid Earth"
date:   2021-05-17 00:00:00 0900
blurb: "Paper published from JGR-Solid Earth"
og_image:
tag: news
category: en
cont: Paper
year: 2021
---

#### **Paper published from JGR-Solid Earth**

My first-authored paper has been published from *Journal of Geophysical Research - Solid Earth*!
The co-authors are Drs. Hiroo Kanamori, Luis Rivera, Zhongwen Zhan, Shingo Watada, and Kenji Satake.
You can check the detailed information in "[Works](https://osm3dan.github.io/en/publications)".

The paper is available in [*Journal of Geophysical Research – Solid Earth*](https://doi.org/10.1029/2021JB021693).
