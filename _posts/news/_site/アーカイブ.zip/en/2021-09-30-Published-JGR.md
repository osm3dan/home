---
layout: post
title:  "Publication from JGR-Solid Earth (co-author)"
title_jp: "出版: JGR-Solid Earth"
date:   2021-09-30 00:00:00 0900
blurb: "Co-authored paper published from JGR-Solid Earth"
og_image:
tags: news, news_jp
# <!-- category: en -->
cont: Paper
cont_jp: 共著論文
year: 2021
---

#### **Co-authored paper published from JGR-Solid Earth**

My co-authored paper has been published from *JGR-Solid Earth*!
You can check the detailed information in "[Works](https://osm3dan.github.io/en/publications)".

The paper is available in [*JGR-Solid Earth*](https://doi.org/10.1029/2021JB022139).
