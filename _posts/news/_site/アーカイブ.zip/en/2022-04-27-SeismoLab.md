---
layout: post
title:  "Short Visit & Seminar Talk @Caltech"
title_jp:  "[セミナー発表] University of Leeds, Volcanology Seminar (招待講演)"
date:   2022-04-27 12:00:00 -0700
blurb: ""
og_image:
##tag: news
tag: soon
category: en
cont: Seminar
year: 2022
---

#### **Seminar**

I will visit [**Seismological Laboratory, Caltech**](http://www.seismolab.caltech.edu/index.html) to give a seminar talk in [**the Brown Bag Seminar**](http://www.seismolab.caltech.edu/bag.html).

- [Place] Benioff Room, Seismological Laboratory, Caltech
- [Date Time] 12:00 - 13:00 on Wednesday, April 27, 2022 (UTC-7)
- [Title] **Unusual volcanic tsunamis caused by trapdoor faulting at submarine calderas**
