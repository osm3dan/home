---
layout: post
title:  "Publication from JGR-Solid Earth (1st author)"
title_jp: "出版: JGR-Solid Earth"
date:   2022-09-12 00:00:00 0900
blurb: "Paper published from JGR-Solid Earth"
og_image:
tags: news news_jp
category: en
cont: Paper
cont_jp: 論文
year: 2022
---

#### **Paper published from JGR-Solid Earth**

Title: **Sub-Decadal Volcanic Tsunamis Due To Submarine Trapdoor Faulting at Sumisu Caldera in the Izu–Bonin Arc**
Authors: *Osamu Sandanbata, Shingo Watada, Kenji Satake, Hiroo Kanamori, Luis Rivera, and Zhongwen Zhan*

**Link**: [*Journal of Geophysical Research – Solid Earth*](https://doi.org/10.1029/2022JB024213).
