---
layout: page_news_jp
title:  "This website open!"
title_jp: "ホームページを開設しました．"
date:   2020-10-15 18:00:00 0900
blurb: "This webpage is published."
og_image:
tag: news_jp
category: jp
cont: HP更新
year: 2020
---

#### **Hellow, world!**

I opened this personal website! Information of my reserch activities will be updated here! Please check it out!
