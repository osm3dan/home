---
layout: page_news_jp
title:  "[Seminar] Internal Seminar at NIED"
title_jp:  "防災科研所内セミナー"
date:   2020-11-06 13:30:00 0900
blurb: "Presentation at NIED / セミナー発表 at 防災科研"
og_image:
tag: news_jp
category: jp
cont: セミナー
year: 2020
---

#### **セミナー発表**

**防災科学技術研究所　火山学セミナー（防災科研所内セミナー）**にて，オンライン発表をしました．

- [日時] 2020年11月6日(金) 13:30 〜 14:30
- [セミナー] 火山学セミナー (internal at NIED)
- [題目] **特異な津波を引き起こす火山性地震の物理メカニズム: 海底カルデラ火山における Trapdoor 型断層破壊**
- [発表者] 三反畑修
