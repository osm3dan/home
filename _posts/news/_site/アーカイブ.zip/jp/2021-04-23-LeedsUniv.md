---
layout: page_news_jp
title:  "[Seminar] 英国Leeds大学 火山学セミナー"
title_jp:  "英国Leeds大学 火山学セミナー (招待講演)"
date:   2021-04-23 19:00:00 +0900
blurb: "Leeds University Volcanology Seminarで口頭発表 / Talk at University of Leeds, Volcanology Seminar"
og_image:
tag: news_jp
category: jp
cont: セミナー
year: 2021
---

#### **セミナー発表**

**University of Leeds, Volcanology Seminar／英国Leeds大学 火山学セミナー**にて，セミナー発表をしました．

- [場所] オンライン開催
- [日時] 2021年4月23日(金) 19:00 〜 20:00 (JST/UTC+09:日本時間)
- [題目] **TBA**
- [著者] 三反畑修
