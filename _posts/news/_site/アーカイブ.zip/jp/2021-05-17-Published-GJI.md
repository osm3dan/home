---
layout: page_news_jp
title:  "主著論文がGJI誌から出版"
title_jp: "主著論文がGJI誌から出版"
date:   2021-05-17 00:00:00 0900
blurb: "JGR-Solid Earth誌に新しい論文を投稿しました."
og_image:
tag: news_jp
category: jp
cont: 論文
year: 2021
---

#### **主著論文がGeophysical Journal International誌から出版**

Geophysical Journal International誌から，新しい主著論文が出版されました．
共著者は，綿田辰吾博士，Tung-Cheng Ho博士，佐竹健治博士です．
詳細情報は「[研究成果](https://osm3dan.github.io/jp/publications)」をご覧ください．

投稿された原稿は[Geophysical Journal International](https://doi.org/10.1093/gji/ggab192)からどうぞ．
