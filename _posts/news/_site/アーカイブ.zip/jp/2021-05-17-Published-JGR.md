---
layout: page_news_jp
title:  "主著論文がJGR-Solid Earth誌から出版"
title_jp: "主著論文がJGR-Solid Earth誌から出版"
date:   2021-05-17 00:00:00 0900
blurb: "JGR-Solid Earth誌に新しい論文を投稿しました."
og_image:
tag: news_jp
category: jp
cont: 論文
year: 2021
---

#### **主著論文がJGR-Solid Earth誌から出版**

Journal of Geophysical Research (JGR) - Solid Earth誌から，新しい主著論文が出版されました．
共著者は，金森博雄博士，Luis Rivera博士，Zhongwen Zhan博士，綿田辰吾博士，佐竹健治博士です．
詳細情報は「[研究成果](https://osm3dan.github.io/jp/publications)」をご覧ください．

投稿された原稿は[Journal of Geophysical Research (JGR) - Solid Earth](https://doi.org/10.1029/2021JB021693)からどうぞ．
