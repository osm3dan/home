---
layout: page_news_jp
title:  "共著論文が JGR-Solid Earth 誌から出版"
title_jp: "共著論文がJGR-Solid Earth誌から出版"
date:   2021-09-30 00:00:00 0900
blurb: "JGR-Solid Earth 誌に新しい共著論文を投稿しました."
og_image:
tag: news_jp
category: jp
cont: 論文
year: 2021
---

#### **共著論文が JGR-Solid Earth 誌から出版**

JGR-Solid Earth 誌から，共著論文が出版されました．
詳細情報は「[研究成果](https://osm3dan.github.io/jp/publications)」をご覧ください．

論文は[JGR-Solid Earth](https://doi.org/10.1029/2021JB022139)からどうぞ．
