---
layout: page_news_jp
title:  "短期訪問＋セミナー発表 @Caltech"
title_jp:  "短期訪問＋セミナー発表 @Caltech"
date:   2022-04-27 12:00:00 -0700
blurb: ""
og_image:
## tag: news_jp
tag: soon_jp
category: jp
cont: セミナー
year: 2022
---

#### **セミナー発表**

**Seismological Laboratory, California Institute of Technology** に訪問滞在．**Brown Bag Seminar** で研究発表をします．

- [場所] Benioff Room, Seismological Laboratory, Caltech
- [日時] 12:00 - 13:00 on Wednesday, April 27, 2022 (UTC-7)
- [題目] **Unusual volcanic tsunamis caused by trapdoor faulting at submarine calderas**
